package com.chessvision.vision

import android.graphics.Bitmap
import android.graphics.Color
import com.chessvision.model.BoardRect
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

object BoardDetector {

    /**
     * Scans a captured screen bitmap to locate an 8x8 chessboard region.
     * Uses horizontal/vertical edge-periodicity and checkerboard alternating-color validation.
     */
    fun detectBoard(bitmap: Bitmap): BoardRect? {
        val w = bitmap.width
        val h = bitmap.height
        if (w < 200 || h < 200) return null

        // Work at a fast analysis width (~360px)
        val scale = 360f / w.toFloat()
        val sw = 360
        val sh = (h * scale).roundToInt().coerceAtLeast(100)
        val scaled = Bitmap.createScaledBitmap(bitmap, sw, sh, false)

        val pixels = IntArray(sw * sh)
        scaled.getPixels(pixels, 0, sw, 0, 0, sw, sh)
        if (scaled !== bitmap) scaled.recycle()

        val luma = FloatArray(sw * sh)
        for (i in pixels.indices) {
            val c = pixels[i]
            luma[i] = 0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)
        }

        // Compute row-wise and column-wise gradient energy
        val colGrad = FloatArray(sw)
        val rowGrad = FloatArray(sh)
        for (y in 1 until sh - 1) {
            val rowOff = y * sw
            var rSum = 0f
            for (x in 1 until sw - 1) {
                val gx = abs(luma[rowOff + x + 1] - luma[rowOff + x - 1])
                val gy = abs(luma[rowOff + sw + x] - luma[rowOff - sw + x])
                colGrad[x] += gx
                rSum += gy
            }
            rowGrad[y] = rSum / sw
        }
        for (x in 0 until sw) colGrad[x] /= sh

        // Candidate board sizes in scaled coordinates (most mobile chess boards span 75%-100% of screen width)
        val minSize = (sw * 0.55f).roundToInt()
        val maxSize = min(sw, sh)

        var bestScore = 0f
        var bestLeft = 0
        var bestTop = 0
        var bestSize = 0

        val sizeStep = 8
        for (size in minSize..maxSize step sizeStep) {
            val sq = size / 8f
            // Find best horizontal alignment
            val maxX = sw - size
            var bestX = 0
            var bestXScore = -1f
            for (x in 0..maxX step 4) {
                var s = 0f
                for (k in 0..8) {
                    val gx = (x + k * sq).roundToInt().coerceIn(1, sw - 2)
                    s += colGrad[gx] + 0.5f * colGrad[gx - 1] + 0.5f * colGrad[gx + 1]
                }
                if (s > bestXScore) {
                    bestXScore = s
                    bestX = x
                }
            }

            // Find best vertical alignment
            val maxY = sh - size
            var bestY = 0
            var bestYScore = -1f
            val yStart = (sh * 0.04f).roundToInt()
            val yEnd = (maxY - sh * 0.04f).roundToInt().coerceAtLeast(yStart)
            for (y in yStart..yEnd step 4) {
                var s = 0f
                for (k in 0..8) {
                    val gy = (y + k * sq).roundToInt().coerceIn(1, sh - 2)
                    s += rowGrad[gy] + 0.5f * rowGrad[gy - 1] + 0.5f * rowGrad[gy + 1]
                }
                if (s > bestYScore) {
                    bestYScore = s
                    bestY = y
                }
            }

            // Validate checkerboard alternating corner brightness inside candidate
            val checkerScore = evaluateCheckerboard(luma, sw, sh, bestX, bestY, size)
            val totalScore = (bestXScore + bestYScore) * checkerScore
            if (totalScore > bestScore && checkerScore > 0.35f) {
                bestScore = totalScore
                bestLeft = bestX
                bestTop = bestY
                bestSize = size
            }
        }

        if (bestSize <= 0) return null

        val invScale = 1f / scale
        return BoardRect(
            left = bestLeft * invScale,
            top = bestTop * invScale,
            size = bestSize * invScale,
            confidence = (bestScore / 400f).coerceIn(0.4f, 0.99f),
            isManual = false
        )
    }

    private fun evaluateCheckerboard(
        luma: FloatArray,
        sw: Int,
        sh: Int,
        left: Int,
        top: Int,
        size: Int
    ): Float {
        val sq = size / 8f
        if (sq < 8f) return 0f
        var parity0Sum = 0f
        var parity0Count = 0
        var parity1Sum = 0f
        var parity1Count = 0

        for (r in 0..7) {
            for (c in 0..7) {
                // Sample near top-left corner of square (less likely to be occluded by piece center)
                val sx = (left + c * sq + sq * 0.16f).roundToInt().coerceIn(0, sw - 1)
                val sy = (top + r * sq + sq * 0.16f).roundToInt().coerceIn(0, sh - 1)
                val v = luma[sy * sw + sx]
                if ((r + c) % 2 == 0) {
                    parity0Sum += v
                    parity0Count++
                } else {
                    parity1Sum += v
                    parity1Count++
                }
            }
        }
        if (parity0Count == 0 || parity1Count == 0) return 0f
        val mean0 = parity0Sum / parity0Count
        val mean1 = parity1Sum / parity1Count
        val contrast = abs(mean0 - mean1)
        // Standard chessboards have >= 18 luma units difference between light and dark squares
        return (contrast / 45f).coerceIn(0f, 1.2f)
    }
}
