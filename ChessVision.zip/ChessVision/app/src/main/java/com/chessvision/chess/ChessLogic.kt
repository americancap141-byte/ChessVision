package com.chessvision.chess

import com.chessvision.model.Piece
import com.chessvision.model.PieceColor
import com.chessvision.model.PieceType
import kotlin.math.abs

data class ChessMove(
    val fromFile: Int,
    val fromRank: Int,
    val toFile: Int,
    val toRank: Int,
    val promotion: PieceType? = null
) {
    fun toUci(): String {
        val base = "${'a' + fromFile}${'1' + fromRank}${'a' + toFile}${'1' + toRank}"
        return if (promotion != null) "$base${promotion.fenChar}" else base
    }
}

data class BoardState(
    /** Indexed as [rank * 8 + file] where rank 0 = rank 1 (White back rank), file 0 = a-file */
    val squares: Array<Piece?>,
    val sideToMove: PieceColor = PieceColor.WHITE,
    val whiteCastleKing: Boolean = true,
    val whiteCastleQueen: Boolean = true,
    val blackCastleKing: Boolean = true,
    val blackCastleQueen: Boolean = true,
    val enPassantFile: Int = -1,
    val enPassantRank: Int = -1,
    val halfMoveClock: Int = 0,
    val fullMoveNumber: Int = 1
) {
    fun pieceAt(file: Int, rank: Int): Piece? {
        if (file !in 0..7 || rank !in 0..7) return null
        return squares[rank * 8 + file]
    }

    fun toFen(): String {
        val sb = StringBuilder()
        for (rank in 7 downTo 0) {
            var empty = 0
            for (file in 0..7) {
                val p = pieceAt(file, rank)
                if (p == null) {
                    empty++
                } else {
                    if (empty > 0) {
                        sb.append(empty)
                        empty = 0
                    }
                    sb.append(p.toFenChar())
                }
            }
            if (empty > 0) sb.append(empty)
            if (rank > 0) sb.append('/')
        }
        sb.append(if (sideToMove == PieceColor.WHITE) " w " else " b ")
        val castling = buildString {
            if (whiteCastleKing) append('K')
            if (whiteCastleQueen) append('Q')
            if (blackCastleKing) append('k')
            if (blackCastleQueen) append('q')
        }
        sb.append(castling.ifEmpty { "-" })
        sb.append(' ')
        if (enPassantFile in 0..7 && enPassantRank in 0..7) {
            sb.append("${'a' + enPassantFile}${'1' + enPassantRank}")
        } else {
            sb.append('-')
        }
        sb.append(" $halfMoveClock $fullMoveNumber")
        return sb.toString()
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is BoardState) return false
        return squares.contentEquals(other.squares) &&
            sideToMove == other.sideToMove &&
            whiteCastleKing == other.whiteCastleKing &&
            whiteCastleQueen == other.whiteCastleQueen &&
            blackCastleKing == other.blackCastleKing &&
            blackCastleQueen == other.blackCastleQueen &&
            enPassantFile == other.enPassantFile &&
            enPassantRank == other.enPassantRank
    }

    override fun hashCode(): Int {
        var result = squares.contentHashCode()
        result = 31 * result + sideToMove.hashCode()
        return result
    }

    companion object {
        const val START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

        fun fromFen(fen: String): BoardState? {
            val parts = fen.trim().split(Regex("\\s+"))
            if (parts.size < 2) return null
            val squares = arrayOfNulls<Piece>(64)
            val ranks = parts[0].split('/')
            if (ranks.size != 8) return null
            for (rIdx in 0..7) {
                val rank = 7 - rIdx
                var file = 0
                for (ch in ranks[rIdx]) {
                    if (ch.isDigit()) {
                        file += ch.digitToInt()
                    } else {
                        val parsed = PieceType.fromFenChar(ch) ?: return null
                        if (file !in 0..7) return null
                        squares[rank * 8 + file] = Piece(parsed.first, parsed.second)
                        file++
                    }
                }
                if (file != 8) return null
            }
            val side = if (parts[1] == "b") PieceColor.BLACK else PieceColor.WHITE
            val castling = parts.getOrNull(2) ?: "-"
            val ep = parts.getOrNull(3) ?: "-"
            val epFile = if (ep.length == 2 && ep[0] in 'a'..'h') ep[0] - 'a' else -1
            val epRank = if (ep.length == 2 && ep[1] in '1'..'8') ep[1] - '1' else -1
            val half = parts.getOrNull(4)?.toIntOrNull() ?: 0
            val full = parts.getOrNull(5)?.toIntOrNull() ?: 1
            return BoardState(
                squares = squares,
                sideToMove = side,
                whiteCastleKing = 'K' in castling,
                whiteCastleQueen = 'Q' in castling,
                blackCastleKing = 'k' in castling,
                blackCastleQueen = 'q' in castling,
                enPassantFile = epFile,
                enPassantRank = epRank,
                halfMoveClock = half,
                fullMoveNumber = full
            )
        }
    }
}

object ChessLogic {

    fun generateLegalMoves(state: BoardState): List<ChessMove> {
        val pseudo = generatePseudoLegalMoves(state)
        val legal = ArrayList<ChessMove>(pseudo.size)
        for (move in pseudo) {
            val next = applyMoveUnchecked(state, move)
            if (!isKingAttacked(next, state.sideToMove)) {
                legal.add(move)
            }
        }
        return legal
    }

    fun applyMove(state: BoardState, move: ChessMove): BoardState? {
        val legal = generateLegalMoves(state)
        if (legal.none { it == move }) return null
        return applyMoveUnchecked(state, move)
    }

    fun applyMoveUnchecked(state: BoardState, move: ChessMove): BoardState {
        val nextSquares = state.squares.copyOf()
        val moving = nextSquares[move.fromRank * 8 + move.fromFile]
        val captured = nextSquares[move.toRank * 8 + move.toFile]

        nextSquares[move.fromRank * 8 + move.fromFile] = null
        val placedPiece = if (moving != null && move.promotion != null) {
            Piece(moving.color, move.promotion)
        } else {
            moving
        }
        nextSquares[move.toRank * 8 + move.toFile] = placedPiece

        // En passant capture
        if (moving?.type == PieceType.PAWN && move.toFile == state.enPassantFile && move.toRank == state.enPassantRank) {
            val capturedPawnRank = if (moving.color == PieceColor.WHITE) move.toRank - 1 else move.toRank + 1
            nextSquares[capturedPawnRank * 8 + move.toFile] = null
        }

        // Castling rook move
        if (moving?.type == PieceType.KING && abs(move.toFile - move.fromFile) == 2) {
            if (move.toFile == 6) {
                nextSquares[move.fromRank * 8 + 5] = nextSquares[move.fromRank * 8 + 7]
                nextSquares[move.fromRank * 8 + 7] = null
            } else if (move.toFile == 2) {
                nextSquares[move.fromRank * 8 + 3] = nextSquares[move.fromRank * 8 + 0]
                nextSquares[move.fromRank * 8 + 0] = null
            }
        }

        var wk = state.whiteCastleKing
        var wq = state.whiteCastleQueen
        var bk = state.blackCastleKing
        var bq = state.blackCastleQueen

        if (moving?.type == PieceType.KING) {
            if (moving.color == PieceColor.WHITE) {
                wk = false; wq = false
            } else {
                bk = false; bq = false
            }
        }
        if (move.fromFile == 0 && move.fromRank == 0 || move.toFile == 0 && move.toRank == 0) wq = false
        if (move.fromFile == 7 && move.fromRank == 0 || move.toFile == 7 && move.toRank == 0) wk = false
        if (move.fromFile == 0 && move.fromRank == 7 || move.toFile == 0 && move.toRank == 7) bq = false
        if (move.fromFile == 7 && move.fromRank == 7 || move.toFile == 7 && move.toRank == 7) bk = false

        var epFile = -1
        var epRank = -1
        if (moving?.type == PieceType.PAWN && abs(move.toRank - move.fromRank) == 2) {
            epFile = move.fromFile
            epRank = (move.fromRank + move.toRank) / 2
        }

        val halfClock = if (moving?.type == PieceType.PAWN || captured != null) 0 else state.halfMoveClock + 1
        val fullMove = if (state.sideToMove == PieceColor.BLACK) state.fullMoveNumber + 1 else state.fullMoveNumber

        return BoardState(
            squares = nextSquares,
            sideToMove = state.sideToMove.opposite(),
            whiteCastleKing = wk,
            whiteCastleQueen = wq,
            blackCastleKing = bk,
            blackCastleQueen = bq,
            enPassantFile = epFile,
            enPassantRank = epRank,
            halfMoveClock = halfClock,
            fullMoveNumber = fullMove
        )
    }

    private fun generatePseudoLegalMoves(state: BoardState): List<ChessMove> {
        val moves = ArrayList<ChessMove>(48)
        val side = state.sideToMove
        for (rank in 0..7) {
            for (file in 0..7) {
                val p = state.squares[rank * 8 + file] ?: continue
                if (p.color != side) continue
                when (p.type) {
                    PieceType.PAWN -> addPawnMoves(state, file, rank, side, moves)
                    PieceType.KNIGHT -> addKnightMoves(state, file, rank, side, moves)
                    PieceType.BISHOP -> addSlidingMoves(state, file, rank, side, BISHOP_DIRS, moves)
                    PieceType.ROOK -> addSlidingMoves(state, file, rank, side, ROOK_DIRS, moves)
                    PieceType.QUEEN -> addSlidingMoves(state, file, rank, side, QUEEN_DIRS, moves)
                    PieceType.KING -> addKingMoves(state, file, rank, side, moves)
                }
            }
        }
        return moves
    }

    private fun addPawnMoves(state: BoardState, f: Int, r: Int, side: PieceColor, out: MutableList<ChessMove>) {
        val dir = if (side == PieceColor.WHITE) 1 else -1
        val startRank = if (side == PieceColor.WHITE) 1 else 6
        val promoRank = if (side == PieceColor.WHITE) 7 else 0
        val nextR = r + dir
        if (nextR in 0..7 && state.pieceAt(f, nextR) == null) {
            addPawnPushOrPromo(f, r, f, nextR, promoRank, out)
            if (r == startRank) {
                val doubleR = r + 2 * dir
                if (state.pieceAt(f, doubleR) == null) {
                    out.add(ChessMove(f, r, f, doubleR))
                }
            }
        }
        for (df in intArrayOf(-1, 1)) {
            val nf = f + df
            if (nf !in 0..7 || nextR !in 0..7) continue
            val target = state.pieceAt(nf, nextR)
            if (target != null && target.color != side) {
                addPawnPushOrPromo(f, r, nf, nextR, promoRank, out)
            } else if (nf == state.enPassantFile && nextR == state.enPassantRank) {
                out.add(ChessMove(f, r, nf, nextR))
            }
        }
    }

    private fun addPawnPushOrPromo(ff: Int, fr: Int, tf: Int, tr: Int, promoRank: Int, out: MutableList<ChessMove>) {
        if (tr == promoRank) {
            out.add(ChessMove(ff, fr, tf, tr, PieceType.QUEEN))
            out.add(ChessMove(ff, fr, tf, tr, PieceType.ROOK))
            out.add(ChessMove(ff, fr, tf, tr, PieceType.BISHOP))
            out.add(ChessMove(ff, fr, tf, tr, PieceType.KNIGHT))
        } else {
            out.add(ChessMove(ff, fr, tf, tr))
        }
    }

    private fun addKnightMoves(state: BoardState, f: Int, r: Int, side: PieceColor, out: MutableList<ChessMove>) {
        for (d in KNIGHT_OFFSETS) {
            val nf = f + d[0]
            val nr = r + d[1]
            if (nf !in 0..7 || nr !in 0..7) continue
            val t = state.pieceAt(nf, nr)
            if (t == null || t.color != side) out.add(ChessMove(f, r, nf, nr))
        }
    }

    private fun addSlidingMoves(
        state: BoardState, f: Int, r: Int, side: PieceColor, dirs: Array<IntArray>, out: MutableList<ChessMove>
    ) {
        for (d in dirs) {
            var nf = f + d[0]
            var nr = r + d[1]
            while (nf in 0..7 && nr in 0..7) {
                val t = state.pieceAt(nf, nr)
                if (t == null) {
                    out.add(ChessMove(f, r, nf, nr))
                } else {
                    if (t.color != side) out.add(ChessMove(f, r, nf, nr))
                    break
                }
                nf += d[0]
                nr += d[1]
            }
        }
    }

    private fun addKingMoves(state: BoardState, f: Int, r: Int, side: PieceColor, out: MutableList<ChessMove>) {
        for (d in QUEEN_DIRS) {
            val nf = f + d[0]
            val nr = r + d[1]
            if (nf !in 0..7 || nr !in 0..7) continue
            val t = state.pieceAt(nf, nr)
            if (t == null || t.color != side) out.add(ChessMove(f, r, nf, nr))
        }
        val homeRank = if (side == PieceColor.WHITE) 0 else 7
        if (f == 4 && r == homeRank && !isSquareAttacked(state, 4, homeRank, side.opposite())) {
            val canKing = if (side == PieceColor.WHITE) state.whiteCastleKing else state.blackCastleKing
            if (canKing && state.pieceAt(5, homeRank) == null && state.pieceAt(6, homeRank) == null &&
                state.pieceAt(7, homeRank)?.type == PieceType.ROOK &&
                !isSquareAttacked(state, 5, homeRank, side.opposite()) &&
                !isSquareAttacked(state, 6, homeRank, side.opposite())
            ) {
                out.add(ChessMove(4, homeRank, 6, homeRank))
            }
            val canQueen = if (side == PieceColor.WHITE) state.whiteCastleQueen else state.blackCastleQueen
            if (canQueen && state.pieceAt(3, homeRank) == null && state.pieceAt(2, homeRank) == null &&
                state.pieceAt(1, homeRank) == null &&
                state.pieceAt(0, homeRank)?.type == PieceType.ROOK &&
                !isSquareAttacked(state, 3, homeRank, side.opposite()) &&
                !isSquareAttacked(state, 2, homeRank, side.opposite())
            ) {
                out.add(ChessMove(4, homeRank, 2, homeRank))
            }
        }
    }

    fun isKingAttacked(state: BoardState, kingColor: PieceColor): Boolean {
        for (r in 0..7) {
            for (f in 0..7) {
                val p = state.squares[r * 8 + f]
                if (p?.color == kingColor && p.type == PieceType.KING) {
                    return isSquareAttacked(state, f, r, kingColor.opposite())
                }
            }
        }
        return false
    }

    fun isSquareAttacked(state: BoardState, f: Int, r: Int, byColor: PieceColor): Boolean {
        val pawnDir = if (byColor == PieceColor.WHITE) -1 else 1
        val pr = r + pawnDir
        if (pr in 0..7) {
            for (df in intArrayOf(-1, 1)) {
                val pf = f + df
                if (pf in 0..7) {
                    val p = state.pieceAt(pf, pr)
                    if (p?.color == byColor && p.type == PieceType.PAWN) return true
                }
            }
        }
        for (d in KNIGHT_OFFSETS) {
            val p = state.pieceAt(f + d[0], r + d[1])
            if (p?.color == byColor && p.type == PieceType.KNIGHT) return true
        }
        for (d in QUEEN_DIRS) {
            val p = state.pieceAt(f + d[0], r + d[1])
            if (p?.color == byColor && p.type == PieceType.KING) return true
        }
        for (d in BISHOP_DIRS) {
            var nf = f + d[0]; var nr = r + d[1]
            while (nf in 0..7 && nr in 0..7) {
                val p = state.pieceAt(nf, nr)
                if (p != null) {
                    if (p.color == byColor && (p.type == PieceType.BISHOP || p.type == PieceType.QUEEN)) return true
                    break
                }
                nf += d[0]; nr += d[1]
            }
        }
        for (d in ROOK_DIRS) {
            var nf = f + d[0]; var nr = r + d[1]
            while (nf in 0..7 && nr in 0..7) {
                val p = state.pieceAt(nf, nr)
                if (p != null) {
                    if (p.color == byColor && (p.type == PieceType.ROOK || p.type == PieceType.QUEEN)) return true
                    break
                }
                nf += d[0]; nr += d[1]
            }
        }
        return false
    }

    /**
     * Built-in Alpha-Beta fallback search used if the native Stockfish binary is absent.
     * Returns Pair(bestMove, scoreCpFromWhitePerspective).
     */
    fun findBestMove(state: BoardState, maxDepth: Int, timeLimitMs: Long = 600L): Pair<ChessMove?, Int> {
        val legal = generateLegalMoves(state)
        if (legal.isEmpty()) return null to 0
        val deadline = System.currentTimeMillis() + timeLimitMs
        var bestMove = legal.first()
        var bestEval = 0

        for (depth in 1..maxDepth.coerceIn(1, 5)) {
            if (System.currentTimeMillis() > deadline) break
            var alpha = -1000000
            val beta = 1000000
            var currentBest: ChessMove? = null
            var currentBestScore = -1000000

            val ordered = legal.sortedByDescending { moveScoreGuess(state, it) }
            for (move in ordered) {
                if (System.currentTimeMillis() > deadline && depth > 1) break
                val next = applyMoveUnchecked(state, move)
                val score = -alphaBeta(next, depth - 1, -beta, -alpha, deadline)
                if (score > currentBestScore) {
                    currentBestScore = score
                    currentBest = move
                }
                if (score > alpha) alpha = score
            }
            if (currentBest != null && System.currentTimeMillis() <= deadline) {
                bestMove = currentBest
                bestEval = if (state.sideToMove == PieceColor.WHITE) currentBestScore else -currentBestScore
            }
        }
        return bestMove to bestEval
    }

    private fun alphaBeta(state: BoardState, depth: Int, alphaInit: Int, beta: Int, deadline: Long): Int {
        if (depth <= 0 || System.currentTimeMillis() > deadline) {
            return evaluateRelative(state)
        }
        val moves = generateLegalMoves(state)
        if (moves.isEmpty()) {
            return if (isKingAttacked(state, state.sideToMove)) -90000 - depth else 0
        }
        var alpha = alphaInit
        val ordered = moves.sortedByDescending { moveScoreGuess(state, it) }
        for (move in ordered) {
            val next = applyMoveUnchecked(state, move)
            val score = -alphaBeta(next, depth - 1, -beta, -alpha, deadline)
            if (score >= beta) return beta
            if (score > alpha) alpha = score
        }
        return alpha
    }

    private fun moveScoreGuess(state: BoardState, move: ChessMove): Int {
        var s = 0
        val cap = state.pieceAt(move.toFile, move.toRank)
        val mov = state.pieceAt(move.fromFile, move.fromRank)
        if (cap != null && mov != null) {
            s += 10 * cap.type.materialValue - mov.type.materialValue
        }
        if (move.promotion != null) s += move.promotion.materialValue
        if (move.toFile in 2..5 && move.toRank in 2..5) s += 20
        return s
    }

    private fun evaluateRelative(state: BoardState): Int {
        var whiteScore = 0
        for (r in 0..7) {
            for (f in 0..7) {
                val p = state.squares[r * 8 + f] ?: continue
                val pstRank = if (p.color == PieceColor.WHITE) r else (7 - r)
                val centerBonus = (3.5 - abs(f - 3.5)).toInt() * 6 + (3.5 - abs(pstRank - 3.5)).toInt() * 4
                val v = p.type.materialValue + if (p.type == PieceType.KING) 0 else centerBonus
                if (p.color == PieceColor.WHITE) whiteScore += v else whiteScore -= v
            }
        }
        return if (state.sideToMove == PieceColor.WHITE) whiteScore else -whiteScore
    }

    private val KNIGHT_OFFSETS = arrayOf(
        intArrayOf(-2, -1), intArrayOf(-2, 1), intArrayOf(-1, -2), intArrayOf(-1, 2),
        intArrayOf(1, -2), intArrayOf(1, 2), intArrayOf(2, -1), intArrayOf(2, 1)
    )
    private val BISHOP_DIRS = arrayOf(
        intArrayOf(-1, -1), intArrayOf(-1, 1), intArrayOf(1, -1), intArrayOf(1, 1)
    )
    private val ROOK_DIRS = arrayOf(
        intArrayOf(-1, 0), intArrayOf(1, 0), intArrayOf(0, -1), intArrayOf(0, 1)
    )
    private val QUEEN_DIRS = BISHOP_DIRS + ROOK_DIRS
}
