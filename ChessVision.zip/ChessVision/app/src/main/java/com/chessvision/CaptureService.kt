package com.chessvision

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import com.chessvision.engine.StockfishEngine
import com.chessvision.model.AnalysisResult
import com.chessvision.model.BoardPerspective
import com.chessvision.model.BoardRect
import com.chessvision.model.StrengthPreset
import com.chessvision.overlay.OverlayController
import com.chessvision.vision.BoardDetector
import com.chessvision.vision.ChessGameTracker
import com.chessvision.vision.PieceClassifier
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class CaptureService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "result_data"
        const val EXTRA_STRENGTH = "strength_preset"
        const val EXTRA_PERSPECTIVE = "board_perspective"
        const val ACTION_STOP = "com.chessvision.ACTION_STOP"
        private const val CHANNEL = "chess_vision_capture"
        private const val NOTIFICATION_ID = 42
        @Volatile
        var isRunning: Boolean = false
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val mainHandler = Handler(Looper.getMainLooper())

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlayController: OverlayController? = null
    private var scanJob: Job? = null

    private lateinit var engine: StockfishEngine
    private val gameTracker = ChessGameTracker()

    private var strengthPreset = StrengthPreset.BULLET
    private var perspective = BoardPerspective.AUTO
    private var lockedBoard: BoardRect? = null
    private var lastAnalyzedFen: String? = null
    private var lastResult: AnalysisResult? = null
    private var framesWithoutBoard = 0

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        engine = StockfishEngine(this)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, notification())

        val presetName = intent?.getStringExtra(EXTRA_STRENGTH)
        strengthPreset = presetName?.let {
            runCatching { StrengthPreset.valueOf(it) }.getOrNull()
        } ?: StrengthPreset.BULLET

        val perspName = intent?.getStringExtra(EXTRA_PERSPECTIVE)
        perspective = perspName?.let {
            runCatching { BoardPerspective.valueOf(it) }.getOrNull()
        } ?: BoardPerspective.AUTO

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_DATA)
        }

        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)

        // Required on Android 14+ before createVirtualDisplay
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }, mainHandler)

        val metrics = resources.displayMetrics
        reader = ImageReader.newInstance(metrics.widthPixels, metrics.heightPixels, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay(
            "ChessVisionCapture",
            metrics.widthPixels,
            metrics.heightPixels,
            metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface,
            null,
            mainHandler
        )

        overlayController = OverlayController(
            context = this,
            onAnalyzeNow = { triggerImmediateScan() },
            onFlipSide = { handleFlipSide() },
            onResetBoard = { handleResetBoard() },
            onStopService = { stopSelf() }
        ).also { it.show() }

        startScanLoop()
        return START_NOT_STICKY
    }

    private fun startScanLoop() {
        scanJob?.cancel()
        scanJob = serviceScope.launch {
            delay(250)
            while (isActive) {
                runCatching { processLatestFrame(forceAnalyze = false) }
                delay(250)
            }
        }
    }

    private fun triggerImmediateScan() {
        serviceScope.launch {
            runCatching { processLatestFrame(forceAnalyze = true) }
        }
    }

    private fun handleFlipSide() {
        serviceScope.launch {
            val flipped = gameTracker.flipSideToMove() ?: return@launch
            val fen = flipped.toFen()
            lastAnalyzedFen = fen
            val res = engine.analyze(fen, strengthPreset, gameTracker.isWhiteAtBottom())
            lastResult = res
            withContext(Dispatchers.Main) {
                overlayController?.updateState(lockedBoard, res, flipped.sideToMove)
            }
        }
    }

    private fun handleResetBoard() {
        lockedBoard = null
        lastAnalyzedFen = null
        lastResult = null
        gameTracker.reset()
        mainHandler.post {
            overlayController?.updateState(null, null, null, "جاري إعادة البحث عن الرقعة...")
        }
    }

    private suspend fun processLatestFrame(forceAnalyze: Boolean) {
        val image = reader?.acquireLatestImage() ?: return
        val bitmap = try {
            imageToBitmap(image)
        } finally {
            image.close()
        } ?: return

        try {
            var board = lockedBoard
            if (board == null) {
                board = BoardDetector.detectBoard(bitmap)
                if (board != null) {
                    lockedBoard = board
                    framesWithoutBoard = 0
                } else {
                    framesWithoutBoard++
                    withContext(Dispatchers.Main) {
                        overlayController?.updateState(null, null, null)
                    }
                    return
                }
            }

            val observations = PieceClassifier.classifyBoard(bitmap, board)
            val occupiedCount = observations.count { it.occupied }
            if (occupiedCount < 2) {
                framesWithoutBoard++
                if (framesWithoutBoard >= 4) {
                    lockedBoard = null
                    lastResult = null
                }
                withContext(Dispatchers.Main) {
                    overlayController?.updateState(null, null, null)
                }
                return
            }
            framesWithoutBoard = 0

            val (state, changed) = gameTracker.updateFromObservations(observations, perspective)
            if (state == null) {
                withContext(Dispatchers.Main) {
                    overlayController?.updateState(board, null, null, "في انتظار وضع البداية...")
                }
                return
            }
            val fen = state.toFen()

            if (forceAnalyze || changed || fen != lastAnalyzedFen || lastResult == null) {
                lastAnalyzedFen = fen
                val result = engine.analyze(fen, strengthPreset, gameTracker.isWhiteAtBottom())
                lastResult = result
                withContext(Dispatchers.Main) {
                    overlayController?.updateState(board, result, state.sideToMove)
                }
            }
        } finally {
            bitmap.recycle()
        }
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        val planes = image.planes
        if (planes.isEmpty()) return null
        val buffer = planes[0].buffer
        val pixelStride = planes[0].pixelStride
        val rowStride = planes[0].rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val bmpWidth = image.width + rowPadding / pixelStride
        val raw = Bitmap.createBitmap(bmpWidth, image.height, Bitmap.Config.ARGB_8888)
        raw.copyPixelsFromBuffer(buffer)
        return if (bmpWidth == image.width) {
            raw
        } else {
            val cropped = Bitmap.createBitmap(raw, 0, 0, image.width, image.height)
            raw.recycle()
            cropped
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL,
                "Chess Vision screen capture",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        val stopIntent = Intent(this, CaptureService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL)
                .setContentTitle("Chess Vision")
                .setContentText("تحليل الرقعة نشط (${strengthPreset.titleAr})")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .addAction(Notification.Action.Builder(null, "إيقاف", stopPending).build())
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("Chess Vision")
                .setContentText("تحليل الرقعة نشط")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build()
        }
    }

    override fun onDestroy() {
        isRunning = false
        scanJob?.cancel()
        serviceScope.cancel()
        engine.close()
        overlayController?.hide()
        overlayController = null
        display?.release()
        display = null
        reader?.close()
        reader = null
        projection?.stop()
        projection = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
