package com.chessvision.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.chessvision.model.AnalysisResult
import com.chessvision.model.BoardRect
import com.chessvision.model.PieceColor
import kotlin.math.abs

class OverlayController(
    private val context: Context,
    private val onAnalyzeNow: () -> Unit,
    private val onFlipSide: () -> Unit,
    private val onResetBoard: () -> Unit,
    private val onStopService: () -> Unit
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var arrowView: OverlayArrowView? = null
    private var hudLayout: LinearLayout? = null
    private var statusText: TextView? = null
    private var sideButton: Button? = null
    private var controlsRow: LinearLayout? = null
    private var expanded = false

    fun show() {
        if (!Settings.canDrawOverlays(context)) return
        if (arrowView == null) {
            val av = OverlayArrowView(context)
            val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                overlayWindowType(),
                flags,
                PixelFormat.TRANSLUCENT
            )
            windowManager.addView(av, params)
            arrowView = av
        }
        if (hudLayout == null) {
            createHud()
        }
    }

    private fun createHud() {
        val bg = GradientDrawable().apply {
            setColor(Color.argb(232, 24, 32, 44))
            cornerRadius = 28f
            setStroke(2, Color.argb(180, 0, 230, 118))
        }

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background = bg
            setPadding(22, 14, 22, 14)
        }

        val headerText = TextView(context).apply {
            text = "♟ Chess Vision • جاري المسح..."
            textSize = 13f
            setTextColor(Color.WHITE)
        }
        statusText = headerText

        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = View.GONE
            setPadding(0, 10, 0, 0)
        }
        controlsRow = row

        val btnAnalyze = makeMiniButton("تحليل") { onAnalyzeNow() }
        val btnSide = makeMiniButton("دور: أبيض") { onFlipSide() }
        sideButton = btnSide
        val btnReset = makeMiniButton("ضبط") { onResetBoard() }
        val btnStop = makeMiniButton("إيقاف", Color.argb(220, 198, 40, 40)) { onStopService() }

        row.addView(btnAnalyze)
        row.addView(btnSide)
        row.addView(btnReset)
        row.addView(btnStop)

        container.addView(headerText)
        container.addView(row)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 20
            y = 110
        }

        // Support dragging and tapping to expand/collapse
        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        headerText.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dx) > 8 || abs(dy) > 8) moved = true
                    params.x = initialX - dx
                    params.y = initialY + dy
                    windowManager.updateViewLayout(container, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        expanded = !expanded
                        row.visibility = if (expanded) View.VISIBLE else View.GONE
                    }
                    true
                }
                else -> false
            }
        }

        windowManager.addView(container, params)
        hudLayout = container
    }

    private fun makeMiniButton(
        label: String,
        bgColor: Int = Color.argb(220, 44, 58, 78),
        onClick: () -> Unit
    ): Button {
        return Button(context).apply {
            text = label
            textSize = 11f
            setTextColor(Color.WHITE)
            setPadding(16, 6, 16, 6)
            minHeight = 0
            minimumHeight = 0
            minWidth = 0
            minimumWidth = 0
            val shape = GradientDrawable().apply {
                setColor(bgColor)
                cornerRadius = 16f
            }
            background = shape
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(4, 0, 4, 0)
            }
            layoutParams = lp
            setOnClickListener { onClick() }
        }
    }

    fun updateState(
        board: BoardRect?,
        result: AnalysisResult?,
        sideToMove: PieceColor?,
        statusMessage: String? = null
    ) {
        arrowView?.updateOverlay(board, result)
        sideToMove?.let {
            sideButton?.text = if (it == PieceColor.WHITE) "دور: أبيض" else "دور: أسود"
        }
        statusText?.text = when {
            statusMessage != null -> "♟ $statusMessage"
            result != null -> "♟ ${result.bestMoveUci} (${result.formattedEval()}) • ${result.engineName}"
            board != null -> "♟ تم رصد الرقعة • جاري التحليل..."
            else -> "♟ ابحث عن رقعة شطرنج على الشاشة..."
        }
    }

    fun hide() {
        arrowView?.let {
            try { windowManager.removeView(it) } catch (_: Throwable) {}
        }
        hudLayout?.let {
            try { windowManager.removeView(it) } catch (_: Throwable) {}
        }
        arrowView = null
        hudLayout = null
    }

    private fun overlayWindowType(): Int {
        return if (Build.VERSION.SDK_INT >= 26) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }
}
