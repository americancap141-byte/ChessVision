package com.chessvision.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import com.chessvision.model.AnalysisResult
import com.chessvision.model.BoardRect
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

class OverlayArrowView(context: Context) : View(context) {

    private var boardRect: BoardRect? = null
    private var analysis: AnalysisResult? = null

    private val bracketPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(185, 0, 230, 118)
        style = Paint.Style.STROKE
        strokeWidth = 5f
        strokeCap = Paint.Cap.ROUND
    }

    private val arrowGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(110, 0, 0, 0)
        style = Paint.Style.STROKE
        strokeWidth = 24f
        strokeCap = Paint.Cap.ROUND
    }

    private val arrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(230, 0, 230, 118)
        style = Paint.Style.STROKE
        strokeWidth = 14f
        strokeCap = Paint.Cap.ROUND
    }

    private val arrowHeadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(240, 0, 230, 118)
        style = Paint.Style.FILL
    }

    private val badgeBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(220, 20, 28, 38)
        style = Paint.Style.FILL
    }

    private val badgeTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 30f
        isFakeBoldText = true
        textAlign = Paint.Align.CENTER
    }

    fun updateOverlay(board: BoardRect?, result: AnalysisResult?) {
        boardRect = board
        analysis = result
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val board = boardRect ?: return

        // Draw subtle corner brackets around detected board
        drawCornerBrackets(canvas, board)

        // Draw best-move arrow if available
        val res = analysis ?: return
        val from = res.fromSquare() ?: return
        val to = res.toSquare() ?: return

        val (x1, y1) = board.squareCenter(from.first, from.second, res.whiteAtBottom)
        val (x2, y2) = board.squareCenter(to.first, to.second, res.whiteAtBottom)

        val angle = atan2((y2 - y1).toDouble(), (x2 - x1).toDouble())
        val headLen = (board.squareSize * 0.42f).coerceIn(26f, 54f)

        // Shorten shaft slightly so it meets the base of the arrowhead cleanly
        val shaftEndX = (x2 - headLen * 0.65f * cos(angle)).toFloat()
        val shaftEndY = (y2 - headLen * 0.65f * sin(angle)).toFloat()

        canvas.drawLine(x1, y1, shaftEndX, shaftEndY, arrowGlowPaint)
        canvas.drawLine(x1, y1, shaftEndX, shaftEndY, arrowPaint)

        // Arrowhead triangle
        val wingAngle = Math.toRadians(28.0)
        val p1x = (x2 - headLen * cos(angle - wingAngle)).toFloat()
        val p1y = (y2 - headLen * sin(angle - wingAngle)).toFloat()
        val p2x = (x2 - headLen * cos(angle + wingAngle)).toFloat()
        val p2y = (y2 - headLen * sin(angle + wingAngle)).toFloat()

        val headPath = Path().apply {
            moveTo(x2, y2)
            lineTo(p1x, p1y)
            lineTo(p2x, p2y)
            close()
        }
        canvas.drawPath(headPath, arrowHeadPaint)

        // Draw compact eval badge at destination square corner
        val evalText = res.formattedEval()
        val textW = badgeTextPaint.measureText(evalText)
        val padX = 14f
        val boxW = textW + padX * 2
        val boxH = 40f
        val bx = (x2 - boxW / 2f).coerceIn(8f, width - boxW - 8f)
        val by = (y2 - board.squareSize * 0.55f - boxH).coerceIn(8f, height - boxH - 8f)
        val rect = RectF(bx, by, bx + boxW, by + boxH)
        canvas.drawRoundRect(rect, 12f, 12f, badgeBgPaint)
        canvas.drawText(evalText, rect.centerX(), rect.centerY() + 10f, badgeTextPaint)
    }

    private fun drawCornerBrackets(canvas: Canvas, board: BoardRect) {
        val len = (board.size * 0.06f).coerceIn(18f, 45f)
        val l = board.left
        val t = board.top
        val r = board.right
        val b = board.bottom

        // Top-left
        canvas.drawLine(l, t, l + len, t, bracketPaint)
        canvas.drawLine(l, t, l, t + len, bracketPaint)
        // Top-right
        canvas.drawLine(r, t, r - len, t, bracketPaint)
        canvas.drawLine(r, t, r, t + len, bracketPaint)
        // Bottom-left
        canvas.drawLine(l, b, l + len, b, bracketPaint)
        canvas.drawLine(l, b, l, b - len, bracketPaint)
        // Bottom-right
        canvas.drawLine(r, b, r - len, b, bracketPaint)
        canvas.drawLine(r, b, r, b - len, bracketPaint)
    }
}
