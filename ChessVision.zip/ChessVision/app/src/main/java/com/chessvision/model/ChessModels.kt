package com.chessvision.model

import android.graphics.RectF

enum class PieceColor {
    WHITE, BLACK;

    fun opposite(): PieceColor = if (this == WHITE) BLACK else WHITE
}

enum class PieceType(val fenChar: Char, val symbol: String, val materialValue: Int) {
    PAWN('p', "", 100),
    KNIGHT('n', "N", 320),
    BISHOP('b', "B", 330),
    ROOK('r', "R", 500),
    QUEEN('q', "Q", 900),
    KING('k', "K", 20000);

    fun toFenChar(color: PieceColor): Char =
        if (color == PieceColor.WHITE) fenChar.uppercaseChar() else fenChar.lowercaseChar()

    companion object {
        fun fromFenChar(c: Char): Pair<PieceColor, PieceType>? {
            val color = if (c.isUpperCase()) PieceColor.WHITE else PieceColor.BLACK
            val type = when (c.lowercaseChar()) {
                'p' -> PAWN
                'n' -> KNIGHT
                'b' -> BISHOP
                'r' -> ROOK
                'q' -> QUEEN
                'k' -> KING
                else -> return null
            }
            return color to type
        }
    }
}

data class Piece(
    val color: PieceColor,
    val type: PieceType
) {
    fun toFenChar(): Char = type.toFenChar(color)
}

enum class BoardPerspective(val labelAr: String) {
    AUTO("تلقائي"),
    WHITE_BOTTOM("الأبيض بالأسفل"),
    BLACK_BOTTOM("الأسود بالأسفل")
}

enum class StrengthPreset(
    val titleAr: String,
    val titleEn: String,
    val targetElo: Int,
    val limitStrength: Boolean,
    val skillLevel: Int,
    val moveTimeMs: Int,
    val fallbackDepth: Int
) {
    BEGINNER("مبتدئ (~1320)", "Beginner", 1320, true, 2, 180, 2),
    CLUB("نادي (~1550)", "Club", 1550, true, 7, 280, 3),
    ADVANCED("متقدم (~1850)", "Advanced", 1850, true, 12, 420, 3),
    MASTER("ماستر (~2200)", "Master", 2200, true, 17, 650, 4),
    GRANDMASTER("أقصى قوة", "Max SF", 3200, false, 20, 950, 4)
}

data class BoardRect(
    val left: Float,
    val top: Float,
    val size: Float,
    val confidence: Float = 1f,
    val isManual: Boolean = false
) {
    val right: Float get() = left + size
    val bottom: Float get() = top + size
    val squareSize: Float get() = size / 8f

    fun toRectF(): RectF = RectF(left, top, right, bottom)

    /**
     * Converts standard chess coordinates (file 0..7 = a..h, rank 0..7 = 1..8)
     * to screen pixel center (x, y) taking board perspective into account.
     */
    fun squareCenter(file: Int, rank: Int, whiteAtBottom: Boolean): Pair<Float, Float> {
        val col = if (whiteAtBottom) file else (7 - file)
        val row = if (whiteAtBottom) (7 - rank) else rank
        val cx = left + (col + 0.5f) * squareSize
        val cy = top + (row + 0.5f) * squareSize
        return cx to cy
    }
}

data class SquareObservation(
    val occupied: Boolean,
    val pieceColor: PieceColor? = null,
    val detectedType: PieceType? = null,
    val confidence: Float = 0f
)

data class AnalysisResult(
    val fen: String,
    val bestMoveUci: String,
    val ponderUci: String? = null,
    val scoreCp: Int = 0,
    val mateIn: Int? = null,
    val pvLine: String = "",
    val engineName: String = "Stockfish",
    val depth: Int = 0,
    val whiteAtBottom: Boolean = true
) {
    fun formattedEval(): String {
        mateIn?.let { m ->
            return if (m > 0) "+M$m" else "-M${kotlin.math.abs(m)}"
        }
        val pawns = scoreCp / 100.0
        val sign = if (pawns >= 0) "+" else ""
        return String.format(java.util.Locale.US, "%s%.2f", sign, pawns)
    }

    fun fromSquare(): Pair<Int, Int>? = parseSquare(bestMoveUci.take(2))
    fun toSquare(): Pair<Int, Int>? = parseSquare(bestMoveUci.drop(2).take(2))

    private fun parseSquare(sq: String): Pair<Int, Int>? {
        if (sq.length != 2) return null
        val file = sq[0] - 'a'
        val rank = sq[1] - '1'
        if (file !in 0..7 || rank !in 0..7) return null
        return file to rank
    }
}
