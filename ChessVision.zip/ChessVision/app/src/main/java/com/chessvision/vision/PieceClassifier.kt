package com.chessvision.vision

import android.graphics.Bitmap
import android.graphics.Color
import com.chessvision.model.BoardRect
import com.chessvision.model.PieceColor
import com.chessvision.model.PieceType
import com.chessvision.model.SquareObservation
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sqrt

object PieceClassifier {

    /**
     * Extracts 64 SquareObservation entries ordered top-to-bottom (row 0..7), left-to-right (col 0..7).
     * Uses center-square contrast/edge variance for occupancy (immune to wood grain) and
     * 80th-percentile interior luminance for White vs Black separation (immune to dark outlines on light squares).
     */
    fun classifyBoard(bitmap: Bitmap, board: BoardRect): Array<SquareObservation> {
        val result = Array(64) { SquareObservation(occupied = false) }
        val sqSize = board.squareSize
        if (sqSize < 12f) return result

        data class RawSquare(
            val occupied: Boolean,
            val interiorP80Luma: Float,
            val fgRatio: Float,
            val topWidth: Float,
            val midWidth: Float,
            val baseWidth: Float,
            val heightSpan: Float
        )

        val rawSquares = Array(64) { RawSquare(false, 0f, 0f, 0f, 0f, 0f, 0f) }
        val occupiedLumas = ArrayList<Float>(32)

        val gridN = 20
        val fgMask = BooleanArray(gridN * gridN)
        val lumas = FloatArray(gridN * gridN)

        for (row in 0..7) {
            for (col in 0..7) {
                val x0 = (board.left + col * sqSize).roundToInt().coerceIn(0, bitmap.width - 1)
                val y0 = (board.top + row * sqSize).roundToInt().coerceIn(0, bitmap.height - 1)
                val s = sqSize.roundToInt().coerceAtLeast(1)

                // Sample 20x20 grid
                val borderR = ArrayList<Int>(16)
                val borderG = ArrayList<Int>(16)
                val borderB = ArrayList<Int>(16)

                for (gy in 0 until gridN) {
                    val py = (y0 + (gy + 0.5f) / gridN * s).roundToInt().coerceIn(0, bitmap.height - 1)
                    for (gx in 0 until gridN) {
                        val px = (x0 + (gx + 0.5f) / gridN * s).roundToInt().coerceIn(0, bitmap.width - 1)
                        val c = bitmap.getPixel(px, py)
                        val r = Color.red(c)
                        val g = Color.green(c)
                        val b = Color.blue(c)
                        lumas[gy * gridN + gx] = 0.299f * r + 0.587f * g + 0.114f * b

                        if ((gy == 1 || gy == gridN - 2) && (gx in 2 until gridN - 2 step 3)) {
                            borderR.add(r); borderG.add(g); borderB.add(b)
                        }
                    }
                }

                // Median border color resists wood-grain outliers
                val bgR = borderR.sorted()[borderR.size / 2].toFloat()
                val bgG = borderG.sorted()[borderG.size / 2].toFloat()
                val bgB = borderB.sorted()[borderB.size / 2].toFloat()
                val bgLuma = 0.299f * bgR + 0.587f * bgG + 0.114f * bgB

                var fgCount = 0
                var edgeEnergy = 0f
                val centerLumas = ArrayList<Float>(100)
                fgMask.fill(false)

                for (gy in 2 until gridN - 2) {
                    val py = (y0 + (gy + 0.5f) / gridN * s).roundToInt().coerceIn(0, bitmap.height - 1)
                    for (gx in 2 until gridN - 2) {
                        val px = (x0 + (gx + 0.5f) / gridN * s).roundToInt().coerceIn(0, bitmap.width - 1)
                        val c = bitmap.getPixel(px, py)
                        val dr = Color.red(c) - bgR
                        val dg = Color.green(c) - bgG
                        val db = Color.blue(c) - bgB
                        val dist = sqrt(dr * dr + dg * dg + db * db)

                        val l = lumas[gy * gridN + gx]
                        val grad = abs(l - lumas[gy * gridN + (gx - 1)]) + abs(l - lumas[(gy - 1) * gridN + gx])
                        if (gx in 5..14 && gy in 5..14) {
                            edgeEnergy += grad
                            centerLumas.add(l)
                        }

                        if (dist > 28f || abs(l - bgLuma) > 24f) {
                            fgMask[gy * gridN + gx] = true
                            fgCount++
                        }
                    }
                }

                val interiorTotal = (gridN - 4) * (gridN - 4)
                val fgRatio = fgCount.toFloat() / interiorTotal.toFloat()
                val avgEdge = edgeEnergy / 100f

                // Occupied if enough foreground pixels OR strong internal piece edges
                val isOccupied = fgRatio >= 0.09f || (avgEdge > 15f && fgRatio >= 0.04f)

                if (isOccupied && centerLumas.isNotEmpty()) {
                    // Use 82nd percentile luma in the center of the square:
                    // White pieces have bright interiors (>175), Black pieces have dark interiors (<125)
                    val sortedCenter = centerLumas.sorted()
                    val p82 = sortedCenter[((sortedCenter.size - 1) * 0.82f).toInt()]
                    occupiedLumas.add(p82)

                    val topW = bandWidthRatio(fgMask, gridN, 3..6)
                    val midW = bandWidthRatio(fgMask, gridN, 8..11)
                    val baseW = bandWidthRatio(fgMask, gridN, 13..16)
                    val hSpan = verticalSpanRatio(fgMask, gridN)

                    rawSquares[row * 8 + col] = RawSquare(
                        occupied = true,
                        interiorP80Luma = p82,
                        fgRatio = fgRatio,
                        topWidth = topW,
                        midWidth = midW,
                        baseWidth = baseW,
                        heightSpan = hSpan
                    )
                }
            }
        }

        // Compute adaptive luma threshold between White and Black pieces
        val colorThreshold = if (occupiedLumas.size >= 4) {
            val sorted = occupiedLumas.sorted()
            val lowMean = sorted.take((sorted.size / 2).coerceAtLeast(1)).average().toFloat()
            val highMean = sorted.takeLast((sorted.size / 2).coerceAtLeast(1)).average().toFloat()
            if (highMean - lowMean > 30f) (lowMean + highMean) * 0.5f else 148f
        } else {
            148f
        }

        for (i in 0..63) {
            val raw = rawSquares[i]
            if (!raw.occupied) {
                result[i] = SquareObservation(occupied = false, confidence = 0.9f)
            } else {
                val color = if (raw.interiorP80Luma >= colorThreshold) PieceColor.WHITE else PieceColor.BLACK
                val type = estimatePieceType(raw.fgRatio, raw.topWidth, raw.midWidth, raw.baseWidth, raw.heightSpan)
                val conf = (abs(raw.interiorP80Luma - colorThreshold) / 70f).coerceIn(0.55f, 0.98f)
                result[i] = SquareObservation(
                    occupied = true,
                    pieceColor = color,
                    detectedType = type,
                    confidence = conf
                )
            }
        }

        return result
    }

    private fun estimatePieceType(
        fgRatio: Float,
        topW: Float,
        midW: Float,
        baseW: Float,
        hSpan: Float
    ): PieceType {
        if (fgRatio < 0.24f && hSpan < 0.65f && topW < 0.34f) {
            return PieceType.PAWN
        }
        if (topW >= 0.48f && midW >= 0.36f && abs(topW - baseW) < 0.22f) {
            return PieceType.ROOK
        }
        if (hSpan >= 0.72f && fgRatio >= 0.34f) {
            return if (topW > midW * 1.05f) PieceType.QUEEN else PieceType.KING
        }
        if (midW >= 0.44f && fgRatio >= 0.28f) {
            return PieceType.KNIGHT
        }
        if (hSpan >= 0.62f && topW < baseW * 0.75f) {
            return PieceType.BISHOP
        }
        return PieceType.PAWN
    }

    private fun bandWidthRatio(mask: BooleanArray, gridN: Int, rows: IntRange): Float {
        var total = 0f
        var count = 0
        for (gy in rows) {
            var minX = gridN
            var maxX = -1
            for (gx in 2 until gridN - 2) {
                if (mask[gy * gridN + gx]) {
                    if (gx < minX) minX = gx
                    if (gx > maxX) maxX = gx
                }
            }
            if (maxX >= minX) {
                total += (maxX - minX + 1).toFloat() / (gridN - 4).toFloat()
            }
            count++
        }
        return if (count > 0) total / count else 0f
    }

    private fun verticalSpanRatio(mask: BooleanArray, gridN: Int): Float {
        var minY = gridN
        var maxY = -1
        for (gy in 2 until gridN - 2) {
            for (gx in 2 until gridN - 2) {
                if (mask[gy * gridN + gx]) {
                    if (gy < minY) minY = gy
                    if (gy > maxY) maxY = gy
                }
            }
        }
        return if (maxY >= minY) (maxY - minY + 1).toFloat() / (gridN - 4).toFloat() else 0f
    }
}
