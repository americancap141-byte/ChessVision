package com.chessvision.vision

import android.graphics.Bitmap
import android.graphics.Color
import com.chessvision.model.BoardRect
import com.chessvision.model.PieceColor
import com.chessvision.model.PieceType
import com.chessvision.model.SquareObservation
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sqrt

object PieceClassifier {

    /**
     * Extracts 64 SquareObservation entries ordered top-to-bottom (row 0..7), left-to-right (col 0..7).
     */
    fun classifyBoard(bitmap: Bitmap, board: BoardRect): Array<SquareObservation> {
        val result = Array(64) { SquareObservation(occupied = false) }
        val sqSize = board.squareSize
        if (sqSize < 12f) return result

        // First pass: collect foreground masks & average piece luminance for adaptive White/Black split
        data class RawSquare(
            val occupied: Boolean,
            val fgLuma: Float,
            val fgRatio: Float,
            val topWidth: Float,
            val midWidth: Float,
            val baseWidth: Float,
            val heightSpan: Float
        )

        val rawSquares = Array(64) { RawSquare(false, 0f, 0f, 0f, 0f, 0f, 0f) }
        val occupiedLumas = ArrayList<Float>(32)

        val gridN = 20 // Sample 20x20 per square for fast & accurate silhouette analysis
        val fgMask = BooleanArray(gridN * gridN)

        for (row in 0..7) {
            for (col in 0..7) {
                val x0 = (board.left + col * sqSize).roundToInt().coerceIn(0, bitmap.width - 1)
                val y0 = (board.top + row * sqSize).roundToInt().coerceIn(0, bitmap.height - 1)
                val s = sqSize.roundToInt().coerceAtLeast(1)

                // Estimate square background color from 4 corner samples
                val bgColors = intArrayOf(
                    samplePixel(bitmap, x0 + (s * 0.08f).toInt(), y0 + (s * 0.08f).toInt()),
                    samplePixel(bitmap, x0 + (s * 0.92f).toInt(), y0 + (s * 0.08f).toInt()),
                    samplePixel(bitmap, x0 + (s * 0.08f).toInt(), y0 + (s * 0.92f).toInt()),
                    samplePixel(bitmap, x0 + (s * 0.92f).toInt(), y0 + (s * 0.92f).toInt())
                )
                val bgR = bgColors.map { Color.red(it) }.average().toFloat()
                val bgG = bgColors.map { Color.green(it) }.average().toFloat()
                val bgB = bgColors.map { Color.blue(it) }.average().toFloat()

                var fgCount = 0
                var fgLumaSum = 0f
                fgMask.fill(false)

                for (gy in 2 until gridN - 2) {
                    val py = (y0 + (gy + 0.5f) / gridN * s).roundToInt().coerceIn(0, bitmap.height - 1)
                    for (gx in 2 until gridN - 2) {
                        val px = (x0 + (gx + 0.5f) / gridN * s).roundToInt().coerceIn(0, bitmap.width - 1)
                        val c = bitmap.getPixel(px, py)
                        val dr = Color.red(c) - bgR
                        val dg = Color.green(c) - bgG
                        val db = Color.blue(c) - bgB
                        val dist = sqrt(dr * dr + dg * dg + db * db)
                        if (dist > 34f) {
                            fgMask[gy * gridN + gx] = true
                            fgCount++
                            fgLumaSum += 0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)
                        }
                    }
                }

                val interiorTotal = (gridN - 4) * (gridN - 4)
                val fgRatio = fgCount.toFloat() / interiorTotal.toFloat()

                if (fgRatio >= 0.08f) {
                    val avgLuma = fgLumaSum / fgCount
                    occupiedLumas.add(avgLuma)

                    val topW = bandWidthRatio(fgMask, gridN, 3..6)
                    val midW = bandWidthRatio(fgMask, gridN, 8..11)
                    val baseW = bandWidthRatio(fgMask, gridN, 13..16)
                    val hSpan = verticalSpanRatio(fgMask, gridN)

                    rawSquares[row * 8 + col] = RawSquare(
                        occupied = true,
                        fgLuma = avgLuma,
                        fgRatio = fgRatio,
                        topWidth = topW,
                        midWidth = midW,
                        baseWidth = baseW,
                        heightSpan = hSpan
                    )
                }
            }
        }

        // Compute adaptive luma threshold between White and Black pieces
        val colorThreshold = if (occupiedLumas.size >= 4) {
            val sorted = occupiedLumas.sorted()
            val lowMean = sorted.take((sorted.size / 2).coerceAtLeast(1)).average().toFloat()
            val highMean = sorted.takeLast((sorted.size / 2).coerceAtLeast(1)).average().toFloat()
            if (highMean - lowMean > 35f) (lowMean + highMean) * 0.5f else 128f
        } else {
            128f
        }

        for (i in 0..63) {
            val raw = rawSquares[i]
            if (!raw.occupied) {
                result[i] = SquareObservation(occupied = false, confidence = 0.9f)
            } else {
                val color = if (raw.fgLuma >= colorThreshold) PieceColor.WHITE else PieceColor.BLACK
                val type = estimatePieceType(raw.fgRatio, raw.topWidth, raw.midWidth, raw.baseWidth, raw.heightSpan)
                val conf = (abs(raw.fgLuma - colorThreshold) / 70f).coerceIn(0.55f, 0.98f)
                result[i] = SquareObservation(
                    occupied = true,
                    pieceColor = color,
                    detectedType = type,
                    confidence = conf
                )
            }
        }

        return result
    }

    private fun estimatePieceType(
        fgRatio: Float,
        topW: Float,
        midW: Float,
        baseW: Float,
        hSpan: Float
    ): PieceType {
        // Pawns are smaller overall and narrower at the top
        if (fgRatio < 0.24f && hSpan < 0.65f && topW < 0.34f) {
            return PieceType.PAWN
        }
        // Rooks have wide, flat battlements at the top nearly as wide as the base
        if (topW >= 0.48f && midW >= 0.36f && abs(topW - baseW) < 0.22f) {
            return PieceType.ROOK
        }
        // Queens & Kings are tall with broad tops/crowns
        if (hSpan >= 0.72f && fgRatio >= 0.34f) {
            return if (topW > midW * 1.05f) PieceType.QUEEN else PieceType.KING
        }
        // Knights tend to have bulky mid/upper body and medium height
        if (midW >= 0.44f && fgRatio >= 0.28f) {
            return PieceType.KNIGHT
        }
        // Bishops are tall and tapered at the top
        if (hSpan >= 0.62f && topW < baseW * 0.75f) {
            return PieceType.BISHOP
        }
        return PieceType.PAWN
    }

    private fun bandWidthRatio(mask: BooleanArray, gridN: Int, rows: IntRange): Float {
        var total = 0f
        var count = 0
        for (gy in rows) {
            var minX = gridN
            var maxX = -1
            for (gx in 2 until gridN - 2) {
                if (mask[gy * gridN + gx]) {
                    if (gx < minX) minX = gx
                    if (gx > maxX) maxX = gx
                }
            }
            if (maxX >= minX) {
                total += (maxX - minX + 1).toFloat() / (gridN - 4).toFloat()
            }
            count++
        }
        return if (count > 0) total / count else 0f
    }

    private fun verticalSpanRatio(mask: BooleanArray, gridN: Int): Float {
        var minY = gridN
        var maxY = -1
        for (gy in 2 until gridN - 2) {
            for (gx in 2 until gridN - 2) {
                if (mask[gy * gridN + gx]) {
                    if (gy < minY) minY = gy
                    if (gy > maxY) maxY = gy
                }
            }
        }
        return if (maxY >= minY) (maxY - minY + 1).toFloat() / (gridN - 4).toFloat() else 0f
    }

    private fun samplePixel(bitmap: Bitmap, x: Int, y: Int): Int {
        return bitmap.getPixel(
            x.coerceIn(0, bitmap.width - 1),
            y.coerceIn(0, bitmap.height - 1)
        )
    }
}
