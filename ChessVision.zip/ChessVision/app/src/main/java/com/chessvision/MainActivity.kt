package com.chessvision

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import com.chessvision.engine.StockfishEngine
import com.chessvision.model.BoardPerspective
import com.chessvision.model.StrengthPreset

class MainActivity : Activity() {
    private val captureRequest = 701
    private val notificationRequest = 702
    private lateinit var projectionManager: MediaProjectionManager
    private lateinit var strengthSpinner: Spinner
    private lateinit var perspectiveSpinner: Spinner
    private lateinit var engineBadge: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        val rootScroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#111822"))
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(44, 60, 44, 60)
        }

        val title = TextView(this).apply {
            text = "♟ Chess Vision"
            textSize = 28f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }

        val subtitle = TextView(this).apply {
            text = "مساعد تحليل الشطرنج بالرؤية الحاسوبية ومحرك Stockfish"
            textSize = 14f
            setTextColor(Color.parseColor("#9FB0C7"))
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 28)
        }

        val hasStockfish = StockfishEngine(this).isNativeStockfishAvailable()
        engineBadge = TextView(this).apply {
            text = if (hasStockfish) {
                "✓ محرك Stockfish الأصلي جاهز ومُضمّن"
            } else {
                "⚡ المحرك المدمج نشط (Stockfish يُضاف تلقائياً عند البناء عبر GitHub)"
            }
            textSize = 12.5f
            setTextColor(if (hasStockfish) Color.parseColor("#00E676") else Color.parseColor("#FFD54F"))
            gravity = Gravity.CENTER
            setPadding(24, 16, 24, 16)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1B2636"))
                cornerRadius = 20f
                setStroke(2, Color.parseColor("#2B3B52"))
            }
        }

        val strengthLabel = makeFieldLabel("مستوى قوة التحليل (Stockfish ELO):")
        strengthSpinner = Spinner(this).apply {
            val items = StrengthPreset.entries.map { it.titleAr }
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
            setSelection(2) // Default: Advanced
            setBackgroundColor(Color.parseColor("#E8EEF5"))
        }

        val perspLabel = makeFieldLabel("اتجاه الرقعة:")
        perspectiveSpinner = Spinner(this).apply {
            val items = BoardPerspective.entries.map { it.labelAr }
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
            setSelection(0) // Default: Auto
            setBackgroundColor(Color.parseColor("#E8EEF5"))
        }

        val overlayButton = makeActionButton("1. السماح بالظهور فوق التطبيقات", "#253447") {
            if (!Settings.canDrawOverlays(this)) {
                val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                startActivity(i)
            } else {
                Toast.makeText(this, "إذن الظهور فوق التطبيقات مفعّل بالفعل", Toast.LENGTH_SHORT).show()
            }
        }

        val startButton = makeActionButton("2. بدء التحليل والتقاط الشاشة", "#00B862") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "اسمح أولاً بالظهور فوق التطبيقات", Toast.LENGTH_LONG).show()
                return@makeActionButton
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), notificationRequest)
                return@makeActionButton
            }
            startActivityForResult(projectionManager.createScreenCaptureIntent(), captureRequest)
        }

        val stopButton = makeActionButton("إيقاف التحليل", "#B71C1C") {
            val stop = Intent(this, CaptureService::class.java).apply {
                action = CaptureService.ACTION_STOP
            }
            startService(stop)
            Toast.makeText(this, "تم إيقاف Chess Vision", Toast.LENGTH_SHORT).show()
        }

        val note = TextView(this).apply {
            text = "بعد بدء الالتقاط افتح تطبيق الشطرنج أو موقع التحليل؛ سيتعرف التطبيق على الرقعة تلقائياً ويرسم سهم أفضل نقلة."
            textSize = 13f
            setTextColor(Color.parseColor("#8CA0B8"))
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 0)
        }

        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(engineBadge)
        layout.addView(strengthLabel)
        layout.addView(strengthSpinner)
        layout.addView(perspLabel)
        layout.addView(perspectiveSpinner)
        layout.addView(overlayButton)
        layout.addView(startButton)
        layout.addView(stopButton)
        layout.addView(note)

        rootScroll.addView(layout)
        setContentView(rootScroll)
    }

    private fun makeFieldLabel(text: String): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(Color.parseColor("#D5E0ED"))
            setPadding(0, 28, 0, 10)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
    }

    private fun makeActionButton(label: String, colorHex: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 15f
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(Color.parseColor(colorHex))
                cornerRadius = 24f
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 22, 0, 0)
            }
            layoutParams = lp
            setPadding(24, 24, 24, 24)
            setOnClickListener { onClick() }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == notificationRequest) {
            startActivityForResult(projectionManager.createScreenCaptureIntent(), captureRequest)
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val preset = StrengthPreset.entries.getOrElse(strengthSpinner.selectedItemPosition) {
                StrengthPreset.ADVANCED
            }
            val perspective = BoardPerspective.entries.getOrElse(perspectiveSpinner.selectedItemPosition) {
                BoardPerspective.AUTO
            }
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_DATA, data)
                putExtra(CaptureService.EXTRA_STRENGTH, preset.name)
                putExtra(CaptureService.EXTRA_PERSPECTIVE, perspective.name)
            }
            startForegroundService(service)
            Toast.makeText(this, "بدأ التحليل (${preset.titleAr})", Toast.LENGTH_SHORT).show()
        }
    }
}
