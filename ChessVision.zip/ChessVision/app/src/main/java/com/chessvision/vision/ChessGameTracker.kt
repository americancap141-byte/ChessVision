package com.chessvision.vision

import com.chessvision.chess.BoardState
import com.chessvision.chess.ChessLogic
import com.chessvision.model.BoardPerspective
import com.chessvision.model.PieceColor
import com.chessvision.model.SquareObservation

class ChessGameTracker {

    private var currentState: BoardState? = null
    private var lastWhiteAtBottom: Boolean = true

    fun reset() {
        currentState = null
    }

    fun getCurrentState(): BoardState? = currentState

    fun isWhiteAtBottom(): Boolean = lastWhiteAtBottom

    fun flipSideToMove(): BoardState? {
        val s = currentState ?: return null
        val updated = s.copy(sideToMove = s.sideToMove.opposite())
        currentState = updated
        return updated
    }

    /**
     * Strictly tracks legal moves from the starting position (1-ply and 2-ply),
     * preventing any hallucinated pieces or illegal moves.
     */
    fun updateFromObservations(
        observations: Array<SquareObservation>,
        perspective: BoardPerspective
    ): Pair<BoardState?, Boolean> {
        val whiteAtBottom = resolvePerspective(observations, perspective)
        lastWhiteAtBottom = whiteAtBottom

        val mappedObs = mapToChessCoords(observations, whiteAtBottom)

        // 1. Always recognize the starting position cleanly
        if (matchesStartingPosition(mappedObs)) {
            val start = BoardState.fromFen(BoardState.START_FEN)!!
            val changed = currentState != start
            currentState = start
            return start to changed
        }

        val prev = currentState ?: return null to false

        // 2. If current state still matches screen, no move occurred
        val currentScore = matchesState(prev, mappedObs)
        if (currentScore >= 63) {
            return prev to false
        }

        // 3. Check all 1-ply legal moves from prev
        val legal1 = ChessLogic.generateLegalMoves(prev)
        var best1: BoardState? = null
        var best1Score = 0
        for (move in legal1) {
            val fromObs = mappedObs[move.fromRank * 8 + move.fromFile]
            val toObs = mappedObs[move.toRank * 8 + move.toFile]
            if (fromObs.occupied || !toObs.occupied || toObs.pieceColor != prev.sideToMove) continue

            val next = ChessLogic.applyMoveUnchecked(prev, move)
            val score = matchesState(next, mappedObs)
            if (score > best1Score) {
                best1Score = score
                best1 = next
            }
        }
        if (best1 != null && best1Score >= 62 && best1Score > currentScore) {
            currentState = best1
            return best1 to true
        }

        // 4. Check 2-ply legal moves (in case player + opponent premove happened between frames)
        var best2: BoardState? = null
        var best2Score = 0
        for (m1 in legal1) {
            val fromObs1 = mappedObs[m1.fromRank * 8 + m1.fromFile]
            if (fromObs1.occupied) continue
            val mid = ChessLogic.applyMoveUnchecked(prev, m1)
            val legal2 = ChessLogic.generateLegalMoves(mid)
            for (m2 in legal2) {
                val toObs2 = mappedObs[m2.toRank * 8 + m2.toFile]
                if (!toObs2.occupied || toObs2.pieceColor != mid.sideToMove) continue
                val next2 = ChessLogic.applyMoveUnchecked(mid, m2)
                val score = matchesState(next2, mappedObs)
                if (score > best2Score) {
                    best2Score = score
                    best2 = next2
                }
            }
        }
        if (best2 != null && best2Score >= 63 && best2Score > currentScore) {
            currentState = best2
            return best2 to true
        }

        // Otherwise keep prev state (mid-animation or temporarily occluded square)
        return prev to false
    }

    private fun resolvePerspective(
        observations: Array<SquareObservation>,
        perspective: BoardPerspective
    ): Boolean {
        return when (perspective) {
            BoardPerspective.WHITE_BOTTOM -> true
            BoardPerspective.BLACK_BOTTOM -> false
            BoardPerspective.AUTO -> {
                var topWhite = 0
                var topBlack = 0
                var botWhite = 0
                var botBlack = 0
                for (r in 0..1) {
                    for (c in 0..7) {
                        val obs = observations[r * 8 + c]
                        if (obs.occupied) {
                            if (obs.pieceColor == PieceColor.WHITE) topWhite++ else topBlack++
                        }
                    }
                }
                for (r in 6..7) {
                    for (c in 0..7) {
                        val obs = observations[r * 8 + c]
                        if (obs.occupied) {
                            if (obs.pieceColor == PieceColor.WHITE) botWhite++ else botBlack++
                        }
                    }
                }
                val whiteBottomScore = (botWhite - botBlack) + (topBlack - topWhite)
                if (whiteBottomScore == 0) lastWhiteAtBottom else whiteBottomScore > 0
            }
        }
    }

    private fun mapToChessCoords(
        observations: Array<SquareObservation>,
        whiteAtBottom: Boolean
    ): Array<SquareObservation> {
        val out = Array(64) { SquareObservation(false) }
        for (row in 0..7) {
            for (col in 0..7) {
                val rank = if (whiteAtBottom) (7 - row) else row
                val file = if (whiteAtBottom) col else (7 - col)
                out[rank * 8 + file] = observations[row * 8 + col]
            }
        }
        return out
    }

    private fun matchesStartingPosition(mappedObs: Array<SquareObservation>): Boolean {
        var matches = 0
        for (rank in 0..7) {
            for (file in 0..7) {
                val obs = mappedObs[rank * 8 + file]
                val expectedOccupied = rank in listOf(0, 1, 6, 7)
                val expectedColor = when (rank) {
                    0, 1 -> PieceColor.WHITE
                    6, 7 -> PieceColor.BLACK
                    else -> null
                }
                if (obs.occupied == expectedOccupied && (!expectedOccupied || obs.pieceColor == expectedColor)) {
                    matches++
                }
            }
        }
        return matches >= 61
    }

    private fun matchesState(state: BoardState, mappedObs: Array<SquareObservation>): Int {
        var score = 0
        for (i in 0..63) {
            val piece = state.squares[i]
            val obs = mappedObs[i]
            if (piece == null && !obs.occupied) {
                score++
            } else if (piece != null && obs.occupied && piece.color == obs.pieceColor) {
                score++
            }
        }
        return score
    }
}
