package com.chessvision.vision

import com.chessvision.chess.BoardState
import com.chessvision.chess.ChessLogic
import com.chessvision.model.BoardPerspective
import com.chessvision.model.Piece
import com.chessvision.model.PieceColor
import com.chessvision.model.PieceType
import com.chessvision.model.SquareObservation

class ChessGameTracker {

    private var currentState: BoardState? = null
    private var lastWhiteAtBottom: Boolean = true

    fun reset() {
        currentState = null
    }

    fun getCurrentState(): BoardState? = currentState

    fun isWhiteAtBottom(): Boolean = lastWhiteAtBottom

    fun flipSideToMove(): BoardState? {
        val s = currentState ?: return null
        val updated = s.copy(sideToMove = s.sideToMove.opposite())
        currentState = updated
        return updated
    }

    /**
     * Updates or reconstructs the BoardState from 64 top-to-bottom, left-to-right SquareObservations.
     * Returns the updated BoardState and whether the board changed since the previous frame.
     */
    fun updateFromObservations(
        observations: Array<SquareObservation>,
        perspective: BoardPerspective,
        preferredSideToMove: PieceColor? = null
    ): Pair<BoardState, Boolean> {
        val whiteAtBottom = resolvePerspective(observations, perspective)
        lastWhiteAtBottom = whiteAtBottom

        val mappedObs = mapToChessCoords(observations, whiteAtBottom)

        // 1. Check if this looks like the standard starting position
        if (matchesStartingPosition(mappedObs)) {
            val start = BoardState.fromFen(BoardState.START_FEN)!!
            val changed = currentState != start
            currentState = start
            return start to changed
        }

        // 2. Try legal move reconstruction from previous known state
        val prev = currentState
        if (prev != null) {
            if (matchesState(prev, mappedObs) >= 63) {
                return prev to false
            }

            // Try 1-ply legal move from prev
            val legalMoves = ChessLogic.generateLegalMoves(prev)
            var bestCandidate: BoardState? = null
            var bestScore = 0
            for (move in legalMoves) {
                val next = ChessLogic.applyMoveUnchecked(prev, move)
                val score = matchesState(next, mappedObs)
                if (score > bestScore) {
                    bestScore = score
                    bestCandidate = next
                }
            }
            if (bestCandidate != null && bestScore >= 62) {
                currentState = bestCandidate
                return bestCandidate to true
            }
        }

        // 3. Fallback: direct FEN reconstruction from observed pieces
        val reconstructed = reconstructFromObservations(
            mappedObs,
            preferredSideToMove ?: prev?.sideToMove ?: PieceColor.WHITE
        )
        val changed = currentState != reconstructed
        currentState = reconstructed
        return reconstructed to changed
    }

    private fun resolvePerspective(
        observations: Array<SquareObservation>,
        perspective: BoardPerspective
    ): Boolean {
        return when (perspective) {
            BoardPerspective.WHITE_BOTTOM -> true
            BoardPerspective.BLACK_BOTTOM -> false
            BoardPerspective.AUTO -> {
                var topWhite = 0
                var topBlack = 0
                var botWhite = 0
                var botBlack = 0
                for (r in 0..1) {
                    for (c in 0..7) {
                        val obs = observations[r * 8 + c]
                        if (obs.occupied) {
                            if (obs.pieceColor == PieceColor.WHITE) topWhite++ else topBlack++
                        }
                    }
                }
                for (r in 6..7) {
                    for (c in 0..7) {
                        val obs = observations[r * 8 + c]
                        if (obs.occupied) {
                            if (obs.pieceColor == PieceColor.WHITE) botWhite++ else botBlack++
                        }
                    }
                }
                val whiteBottomScore = (botWhite - botBlack) + (topBlack - topWhite)
                if (whiteBottomScore == 0) lastWhiteAtBottom else whiteBottomScore > 0
            }
        }
    }

    /**
     * Converts screen-grid [row*8 + col] into chess-grid [rank*8 + file].
     */
    private fun mapToChessCoords(
        observations: Array<SquareObservation>,
        whiteAtBottom: Boolean
    ): Array<SquareObservation> {
        val out = Array(64) { SquareObservation(false) }
        for (row in 0..7) {
            for (col in 0..7) {
                val rank = if (whiteAtBottom) (7 - row) else row
                val file = if (whiteAtBottom) col else (7 - col)
                out[rank * 8 + file] = observations[row * 8 + col]
            }
        }
        return out
    }

    private fun matchesStartingPosition(mappedObs: Array<SquareObservation>): Boolean {
        var matches = 0
        for (rank in 0..7) {
            for (file in 0..7) {
                val obs = mappedObs[rank * 8 + file]
                val expectedOccupied = rank in listOf(0, 1, 6, 7)
                val expectedColor = when (rank) {
                    0, 1 -> PieceColor.WHITE
                    6, 7 -> PieceColor.BLACK
                    else -> null
                }
                if (obs.occupied == expectedOccupied && (!expectedOccupied || obs.pieceColor == expectedColor)) {
                    matches++
                }
            }
        }
        return matches >= 61
    }

    private fun matchesState(state: BoardState, mappedObs: Array<SquareObservation>): Int {
        var score = 0
        for (i in 0..63) {
            val piece = state.squares[i]
            val obs = mappedObs[i]
            if (piece == null && !obs.occupied) {
                score++
            } else if (piece != null && obs.occupied && piece.color == obs.pieceColor) {
                score++
            }
        }
        return score
    }

    private fun reconstructFromObservations(
        mappedObs: Array<SquareObservation>,
        sideToMove: PieceColor
    ): BoardState {
        val squares = arrayOfNulls<Piece>(64)
        var whiteKingCount = 0
        var blackKingCount = 0
        var bestWhiteKingIdx = -1
        var bestBlackKingIdx = -1

        for (i in 0..63) {
            val obs = mappedObs[i]
            if (!obs.occupied || obs.pieceColor == null) continue
            val type = obs.detectedType ?: PieceType.PAWN
            val rank = i / 8
            // Pawns cannot sit on rank 1 or rank 8
            val adjustedType = if (type == PieceType.PAWN && (rank == 0 || rank == 7)) {
                PieceType.ROOK
            } else {
                type
            }
            if (adjustedType == PieceType.KING) {
                if (obs.pieceColor == PieceColor.WHITE) {
                    if (whiteKingCount == 0) {
                        whiteKingCount++
                        squares[i] = Piece(PieceColor.WHITE, PieceType.KING)
                    } else {
                        squares[i] = Piece(PieceColor.WHITE, PieceType.QUEEN)
                    }
                } else {
                    if (blackKingCount == 0) {
                        blackKingCount++
                        squares[i] = Piece(PieceColor.BLACK, PieceType.KING)
                    } else {
                        squares[i] = Piece(PieceColor.BLACK, PieceType.QUEEN)
                    }
                }
            } else {
                squares[i] = Piece(obs.pieceColor, adjustedType)
                if (obs.pieceColor == PieceColor.WHITE && bestWhiteKingIdx == -1) bestWhiteKingIdx = i
                if (obs.pieceColor == PieceColor.BLACK && bestBlackKingIdx == -1) bestBlackKingIdx = i
            }
        }

        // Ensure valid FEN with exactly 1 White King and 1 Black King
        if (whiteKingCount == 0) {
            val idx = if (squares[4] == null) 4 else if (bestWhiteKingIdx != -1) bestWhiteKingIdx else 4
            squares[idx] = Piece(PieceColor.WHITE, PieceType.KING)
        }
        if (blackKingCount == 0) {
            val idx = if (squares[60] == null) 60 else if (bestBlackKingIdx != -1) bestBlackKingIdx else 60
            squares[idx] = Piece(PieceColor.BLACK, PieceType.KING)
        }

        val wk = squares[4]?.let { it.color == PieceColor.WHITE && it.type == PieceType.KING } == true &&
            squares[7]?.let { it.color == PieceColor.WHITE && it.type == PieceType.ROOK } == true
        val wq = squares[4]?.let { it.color == PieceColor.WHITE && it.type == PieceType.KING } == true &&
            squares[0]?.let { it.color == PieceColor.WHITE && it.type == PieceType.ROOK } == true
        val bk = squares[60]?.let { it.color == PieceColor.BLACK && it.type == PieceType.KING } == true &&
            squares[63]?.let { it.color == PieceColor.BLACK && it.type == PieceType.ROOK } == true
        val bq = squares[60]?.let { it.color == PieceColor.BLACK && it.type == PieceType.KING } == true &&
            squares[56]?.let { it.color == PieceColor.BLACK && it.type == PieceType.ROOK } == true

        return BoardState(
            squares = squares,
            sideToMove = sideToMove,
            whiteCastleKing = wk,
            whiteCastleQueen = wq,
            blackCastleKing = bk,
            blackCastleQueen = bq
        )
    }
}
