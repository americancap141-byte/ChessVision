package com.chessvision.engine

import android.content.Context
import com.chessvision.chess.BoardState
import com.chessvision.chess.ChessLogic
import com.chessvision.model.AnalysisResult
import com.chessvision.model.StrengthPreset
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs

class StockfishEngine(@Suppress("UNUSED_PARAMETER") private val context: Context) {

    private val mutex = Mutex()

    fun isNativeStockfishAvailable(): Boolean = true

    suspend fun analyze(
        fen: String,
        preset: StrengthPreset,
        whiteAtBottom: Boolean
    ): AnalysisResult? = mutex.withLock {
        val state = BoardState.fromFen(fen) ?: return@withLock null

        // 1. Try fast Cloud Stockfish 18 API (chess-api.com)
        val cloudResult = withContext(Dispatchers.IO) {
            queryChessApi(fen, preset, whiteAtBottom)
        }
        if (cloudResult != null) return@withLock cloudResult

        // 2. Offline fallback: Built-in Alpha-Beta engine
        val (move, evalWhiteCp) = ChessLogic.findBestMove(state, preset.fallbackDepth, preset.moveTimeMs.toLong())
        val uci = move?.toUci() ?: return@withLock null
        val isMate = abs(evalWhiteCp) >= 80000
        val mateIn = if (isMate) {
            val plies = (90005 - abs(evalWhiteCp)).coerceAtLeast(1)
            val moves = (plies + 1) / 2
            if (evalWhiteCp > 0) moves else -moves
        } else null

        AnalysisResult(
            fen = fen,
            bestMoveUci = uci,
            scoreCp = if (isMate) 0 else evalWhiteCp,
            mateIn = mateIn,
            engineName = "Offline Lite",
            depth = preset.fallbackDepth,
            whiteAtBottom = whiteAtBottom
        )
    }

    private fun queryChessApi(
        fen: String,
        preset: StrengthPreset,
        whiteAtBottom: Boolean
    ): AnalysisResult? {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL("https://chess-api.com/v1")
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 1500
                readTimeout = 2000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }

            val depth = when (preset) {
                StrengthPreset.BULLET -> 10
                StrengthPreset.BEGINNER -> 6
                StrengthPreset.CLUB -> 8
                StrengthPreset.ADVANCED -> 11
                StrengthPreset.MASTER -> 13
                StrengthPreset.GRANDMASTER -> 15
            }

            val payload = JSONObject().apply {
                put("fen", fen)
                put("depth", depth)
            }.toString()

            OutputStreamWriter(conn.outputStream).use { it.write(payload) }

            if (conn.responseCode !in 200..299) return null

            val body = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
            val json = JSONObject(body)
            val move = json.optString("move", "")
            if (move.length < 4) return null

            val mate = if (json.isNull("mate")) null else json.optInt("mate")
            val cpStr = json.optString("centipawns", "")
            val cp = cpStr.toIntOrNull() ?: ((json.optDouble("eval", 0.0) * 100.0).toInt())
            val resDepth = json.optInt("depth", depth)

            AnalysisResult(
                fen = fen,
                bestMoveUci = move,
                scoreCp = if (mate != null) 0 else cp,
                mateIn = mate,
                engineName = "Stockfish 18",
                depth = resDepth,
                whiteAtBottom = whiteAtBottom
            )
        } catch (_: Throwable) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    fun close() {}
}
