package com.chessvision.engine

import android.content.Context
import com.chessvision.chess.BoardState
import com.chessvision.chess.ChessLogic
import com.chessvision.model.AnalysisResult
import com.chessvision.model.PieceColor
import com.chessvision.model.StrengthPreset
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter

class StockfishEngine(private val context: Context) {

    private val mutex = Mutex()
    private var process: Process? = null
    private var writer: BufferedWriter? = null
    private var reader: BufferedReader? = null
    private var uciReady = false
    private var currentPreset: StrengthPreset? = null

    fun isNativeStockfishAvailable(): Boolean {
        val bin = File(context.applicationInfo.nativeLibraryDir, "libstockfish.so")
        return bin.exists() && bin.canExecute()
    }

    suspend fun analyze(
        fen: String,
        preset: StrengthPreset,
        whiteAtBottom: Boolean
    ): AnalysisResult? = mutex.withLock {
        val state = BoardState.fromFen(fen) ?: return@withLock null
        if (ensureStockfishStarted()) {
            val sfResult = analyzeWithStockfish(fen, state.sideToMove, preset, whiteAtBottom)
            if (sfResult != null) return@withLock sfResult
        }
        // Fallback pure-Kotlin Alpha-Beta engine if native binary is not present
        val (move, evalWhiteCp) = ChessLogic.findBestMove(state, preset.fallbackDepth, preset.moveTimeMs.toLong())
        val uci = move?.toUci() ?: return@withLock null
        AnalysisResult(
            fen = fen,
            bestMoveUci = uci,
            scoreCp = evalWhiteCp,
            engineName = "Built-in Lite",
            depth = preset.fallbackDepth,
            whiteAtBottom = whiteAtBottom
        )
    }

    private fun ensureStockfishStarted(): Boolean {
        if (process != null && uciReady) return true
        val bin = File(context.applicationInfo.nativeLibraryDir, "libstockfish.so")
        if (!bin.exists()) return false
        return try {
            val proc = ProcessBuilder(bin.absolutePath)
                .redirectErrorStream(true)
                .start()
            val w = BufferedWriter(OutputStreamWriter(proc.outputStream))
            val r = BufferedReader(InputStreamReader(proc.inputStream))
            process = proc
            writer = w
            reader = r

            sendCommand("uci")
            waitForToken("uciok", 3000)
            sendCommand("setoption name Threads value 2")
            sendCommand("setoption name Hash value 32")
            sendCommand("isready")
            uciReady = waitForToken("readyok", 3000)
            uciReady
        } catch (_: Throwable) {
            close()
            false
        }
    }

    private fun applyPresetIfNeeded(preset: StrengthPreset) {
        if (currentPreset == preset) return
        if (preset.limitStrength) {
            sendCommand("setoption name UCI_LimitStrength value true")
            sendCommand("setoption name UCI_Elo value ${preset.targetElo}")
            sendCommand("setoption name Skill Level value ${preset.skillLevel}")
        } else {
            sendCommand("setoption name UCI_LimitStrength value false")
            sendCommand("setoption name Skill Level value 20")
        }
        sendCommand("isready")
        waitForToken("readyok", 1500)
        currentPreset = preset
    }

    private fun analyzeWithStockfish(
        fen: String,
        sideToMove: PieceColor,
        preset: StrengthPreset,
        whiteAtBottom: Boolean
    ): AnalysisResult? {
        return try {
            applyPresetIfNeeded(preset)
            sendCommand("position fen $fen")
            sendCommand("go movetime ${preset.moveTimeMs}")

            var bestMove: String? = null
            var ponder: String? = null
            var lastScoreCp = 0
            var lastMate: Int? = null
            var lastDepth = 0
            var lastPv = ""

            val deadline = System.currentTimeMillis() + preset.moveTimeMs + 2500L
            while (System.currentTimeMillis() < deadline) {
                val line = reader?.readLine() ?: break
                if (line.startsWith("info ")) {
                    parseInfoLine(line)?.let { info ->
                        lastDepth = info.depth
                        lastScoreCp = if (sideToMove == PieceColor.WHITE) info.cp else -info.cp
                        lastMate = info.mate?.let { m -> if (sideToMove == PieceColor.WHITE) m else -m }
                        lastPv = info.pv
                    }
                } else if (line.startsWith("bestmove ")) {
                    val tokens = line.split(Regex("\\s+"))
                    bestMove = tokens.getOrNull(1)
                    val ponderIdx = tokens.indexOf("ponder")
                    if (ponderIdx != -1) ponder = tokens.getOrNull(ponderIdx + 1)
                    break
                }
            }

            if (bestMove == null || bestMove == "(none)") return null
            AnalysisResult(
                fen = fen,
                bestMoveUci = bestMove,
                ponderUci = ponder,
                scoreCp = lastScoreCp,
                mateIn = lastMate,
                pvLine = lastPv,
                engineName = "Stockfish",
                depth = lastDepth,
                whiteAtBottom = whiteAtBottom
            )
        } catch (_: Throwable) {
            close()
            null
        }
    }

    private data class InfoParsed(val depth: Int, val cp: Int, val mate: Int?, val pv: String)

    private fun parseInfoLine(line: String): InfoParsed? {
        if (!line.contains(" score ")) return null
        val tokens = line.split(Regex("\\s+"))
        var depth = 0
        var cp = 0
        var mate: Int? = null
        var pv = ""
        var i = 0
        while (i < tokens.size) {
            when (tokens[i]) {
                "depth" -> depth = tokens.getOrNull(i + 1)?.toIntOrNull() ?: depth
                "cp" -> cp = tokens.getOrNull(i + 1)?.toIntOrNull() ?: cp
                "mate" -> mate = tokens.getOrNull(i + 1)?.toIntOrNull()
                "pv" -> {
                    pv = tokens.drop(i + 1).take(5).joinToString(" ")
                    break
                }
            }
            i++
        }
        return InfoParsed(depth, cp, mate, pv)
    }

    private fun sendCommand(cmd: String) {
        writer?.apply {
            write(cmd)
            newLine()
            flush()
        }
    }

    private fun waitForToken(token: String, timeoutMs: Long): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            val line = reader?.readLine() ?: return false
            if (line.trim() == token) return true
        }
        return false
    }

    fun close() {
        try { sendCommand("quit") } catch (_: Throwable) {}
        try { writer?.close() } catch (_: Throwable) {}
        try { reader?.close() } catch (_: Throwable) {}
        try { process?.destroy() } catch (_: Throwable) {}
        writer = null
        reader = null
        process = null
        uciReady = false
        currentPreset = null
    }
}
